/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package brgycertificate;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Date;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.RowFilter;
import java.awt.Color;
import java.awt.Font;
import java.awt.Component;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.JTable;
import java.sql.SQLIntegrityConstraintViolationException;






/**
 *
 * @author Erika
 */
public class ResidentsPanel extends javax.swing.JPanel {
    
    
    private TableRowSorter<DefaultTableModel> sorter;


    /**
     * Creates new form ResidentsPanel
     */
    public ResidentsPanel() {
    initComponents();

    // Assuming your table is named 'tblResidents'
javax.swing.table.TableRowSorter sorter = new javax.swing.table.TableRowSorter<>(tableResidents.getModel());
tableResidents.setRowSorter(sorter);

// 🔒 Disable sorting for ID and Contact #
sorter.setSortable(0, false); // Column index 0 = ID
sorter.setSortable(4, false); // Adjust if needed: 4 = Contact No.

// 👁️ Hide the ID column from view (but still usable for code)
tableResidents.getColumnModel().getColumn(0).setMinWidth(0);
tableResidents.getColumnModel().getColumn(0).setMaxWidth(0);
tableResidents.getColumnModel().getColumn(0).setWidth(0);

// MUST BE FIRST
    // attach listener to txtSearchResidents instead
    styleTable();
    
    txtSearchResidents.setToolTipText("Search...");
    txtSearchResidents.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyReleased(java.awt.event.KeyEvent evt) {
            String searchTerm = txtSearchResidents.getText();
        searchResidents(searchTerm);
        }
    });
    loadResidents();
}
private void styleTable() {
        // Minimal + Bagong Pilipinas theme styling
        Color headerBg = new Color(0, 70, 140); // Dark blue
        Color headerFg = Color.WHITE;
        Color rowEven = new Color(245, 245, 245);
        Color rowOdd = Color.WHITE;
        Font headerFont = new Font("Segoe UI", Font.BOLD, 14);
        Font rowFont = new Font("Segoe UI", Font.PLAIN, 13);

        JTableHeader header = tableResidents.getTableHeader();
        header.setBackground(headerBg);
        header.setForeground(headerFg);
        header.setFont(headerFont);
        header.setOpaque(true);
        header.setReorderingAllowed(false);

        tableResidents.setFont(rowFont);
        tableResidents.setRowHeight(28);

        // Set alternating row colors
        tableResidents.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? rowEven : rowOdd);
                }
                return c;
            }
        });
    }
   private void searchResidents(String query) {
    DefaultTableModel model = (DefaultTableModel) tableResidents.getModel();
    if (sorter == null) {
        sorter = new TableRowSorter<>(model);
        tableResidents.setRowSorter(sorter);
    }
    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + query)); // Case-insensitive search
}


private void loadResidents() {
    DefaultTableModel model = (DefaultTableModel) tableResidents.getModel();
    model.setRowCount(0);

    try {
        Connection conn = DBConnection.getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM residents");

        while (rs.next()) {
    model.addRow(new Object[] {
        rs.getInt("id"),
        rs.getString("first_name"),
        rs.getString("last_name"),
        rs.getString("address"),
        rs.getString("contact_number"),
        rs.getString("civil_status"),
        rs.getDate("birthdate")
    });
}


        conn.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
private void clearFields() {
    btnAdd.setEnabled(true);
btnUpdate.setEnabled(false);
btnDelete.setEnabled(false);

    txtFirstName.setText("");
    txtLastName.setText("");
    txtAddress.setText("");
    txtContact.setText("");
    cmbStatus.setSelectedIndex(0);
    dateBirth.setDate(null); // ✅ use the correct field here
}




    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelTable = new javax.swing.JPanel();
        txtSearchResidents = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableResidents = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        panelForm = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtFirstName = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtLastName = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtAddress = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtContact = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        cmbStatus = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        dateBirth = new com.toedter.calendar.JDateChooser();
        btnAdd = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();

        setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.LINE_AXIS));

        panelTable.setBackground(new java.awt.Color(240, 240, 240));

        txtSearchResidents.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtSearchResidents.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102), new java.awt.Color(0, 0, 0), new java.awt.Color(102, 102, 102)));
        txtSearchResidents.setPreferredSize(new java.awt.Dimension(64, 10));
        txtSearchResidents.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSearchResidentsActionPerformed(evt);
            }
        });

        tableResidents.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "First Name", "Last Name", "Purok #", "Contact #", "Civil Status", "Birthdate"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tableResidents.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableResidentsMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tableResidents);
        if (tableResidents.getColumnModel().getColumnCount() > 0) {
            tableResidents.getColumnModel().getColumn(0).setResizable(false);
            tableResidents.getColumnModel().getColumn(0).setHeaderValue("ID");
            tableResidents.getColumnModel().getColumn(1).setResizable(false);
            tableResidents.getColumnModel().getColumn(2).setResizable(false);
            tableResidents.getColumnModel().getColumn(3).setResizable(false);
            tableResidents.getColumnModel().getColumn(4).setResizable(false);
            tableResidents.getColumnModel().getColumn(5).setResizable(false);
            tableResidents.getColumnModel().getColumn(6).setResizable(false);
        }

        jLabel7.setText("Search:");

        panelForm.setBackground(new java.awt.Color(240, 240, 240));
        panelForm.setPreferredSize(new java.awt.Dimension(1, 494));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel1.setText("First Name:");

        txtFirstName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFirstNameActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setText("Last Name:");

        txtLastName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLastNameActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setText("Purok #:");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setText("Contact #:");

        txtContact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContactActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setText("Civil Status:");

        cmbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Single", "Married", "Divorced", "Widowed" }));
        cmbStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbStatusActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setText("Birthday:");

        btnAdd.setBackground(new java.awt.Color(0, 204, 0));
        btnAdd.setText("ADD");
        btnAdd.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0)));
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnUpdate.setBackground(new java.awt.Color(51, 102, 255));
        btnUpdate.setText("UPDATE");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        btnDelete.setBackground(new java.awt.Color(255, 0, 0));
        btnDelete.setText("DELETE");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnClear.setBackground(new java.awt.Color(102, 102, 102));
        btnClear.setForeground(new java.awt.Color(255, 255, 255));
        btnClear.setText("CLEAR");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelFormLayout = new javax.swing.GroupLayout(panelForm);
        panelForm.setLayout(panelFormLayout);
        panelFormLayout.setHorizontalGroup(
            panelFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFormLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(panelFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addGroup(panelFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnUpdate, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(btnAdd, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(panelFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(dateBirth, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
                        .addComponent(cmbStatus, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtContact, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txtAddress, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txtLastName, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txtFirstName, javax.swing.GroupLayout.Alignment.LEADING)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelFormLayout.setVerticalGroup(
            panelFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFormLayout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtContact, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dateBirth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23)
                .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jLabel8.setFont(new java.awt.Font("Wide Latin", 1, 24)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("RESIDENTS");

        javax.swing.GroupLayout panelTableLayout = new javax.swing.GroupLayout(panelTable);
        panelTable.setLayout(panelTableLayout);
        panelTableLayout.setHorizontalGroup(
            panelTableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTableLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelForm, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(panelTableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelTableLayout.createSequentialGroup()
                        .addGap(296, 296, 296)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(118, 118, 118)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtSearchResidents, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelTableLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 972, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        panelTableLayout.setVerticalGroup(
            panelTableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTableLayout.createSequentialGroup()
                .addGroup(panelTableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelTableLayout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addGroup(panelTableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtSearchResidents, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 581, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(panelForm, javax.swing.GroupLayout.PREFERRED_SIZE, 643, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        add(panelTable);
    }// </editor-fold>//GEN-END:initComponents

    private void tableResidentsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableResidentsMouseClicked
      btnAdd.setEnabled(false); // Disable Add when row is selected
btnUpdate.setEnabled(true); // Make sure Update is enabled
btnDelete.setEnabled(true);

        int row = tableResidents.getSelectedRow();

        txtFirstName.setText(tableResidents.getValueAt(row, 1).toString());
        txtLastName.setText(tableResidents.getValueAt(row, 2).toString());
        txtAddress.setText(tableResidents.getValueAt(row, 3).toString());
        txtContact.setText(tableResidents.getValueAt(row, 4).toString());
        cmbStatus.setSelectedItem(tableResidents.getValueAt(row, 5).toString());
        dateBirth.setDate(java.sql.Date.valueOf(tableResidents.getValueAt(row, 6).toString()));
        // TODO add your handling code here:
    }//GEN-LAST:event_tableResidentsMouseClicked

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
int row = tableResidents.getSelectedRow();
if (row == -1) {
    JOptionPane.showMessageDialog(this, "Please select a resident to delete.");
    return;
}

int id = (int) tableResidents.getValueAt(row, 0); // Get ID from column 0

// ✅ STEP 1: Fetch the resident's full name BEFORE deleting
String fullName = "";
try {
    Connection conn = DBConnection.getConnection();

    // Get full name
    String getNameSQL = "SELECT first_name, last_name FROM residents WHERE id = ?";
    PreparedStatement getNameStmt = conn.prepareStatement(getNameSQL);
    getNameStmt.setInt(1, id);
    ResultSet rs = getNameStmt.executeQuery();

    if (rs.next()) {
        fullName = rs.getString("first_name") + " " + rs.getString("last_name");
    }

    // ✅ STEP 2: Confirm deletion
    int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete " + fullName + "?", "Confirm", JOptionPane.YES_NO_OPTION);
    if (confirm != JOptionPane.YES_OPTION) return;

    // ✅ STEP 3: Delete any related certificates first
    String deleteCertSQL = "DELETE FROM certificates WHERE resident_id = ?";
    PreparedStatement deleteCertStmt = conn.prepareStatement(deleteCertSQL);
    deleteCertStmt.setInt(1, id);
    deleteCertStmt.executeUpdate();

    // ✅ STEP 4: Now delete the resident
    String deleteResidentSQL = "DELETE FROM residents WHERE id = ?";
    PreparedStatement deleteResidentStmt = conn.prepareStatement(deleteResidentSQL);
    deleteResidentStmt.setInt(1, id);
    deleteResidentStmt.executeUpdate();

    // ✅ STEP 5: Log using the full name
    ActivityLogger.log("Deleted resident: " + fullName, MainDashboard.currentUser);

    JOptionPane.showMessageDialog(this, "Resident deleted successfully!");

    loadResidents(); // refresh table
    clearFields();   // reset input

    // Close connections
    rs.close();
    getNameStmt.close();
    deleteCertStmt.close();
    deleteResidentStmt.close();
    conn.close();

} catch (Exception e) {
    e.printStackTrace();
    JOptionPane.showMessageDialog(this, "Delete failed: " + e.getMessage());
}

        // TODO add your handling code here:
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
     String firstName = txtFirstName.getText().trim();
    String lastName = txtLastName.getText().trim();
    String purok = txtAddress.getText().trim();  // Stored in 'address'
    String contact = txtContact.getText().trim();
    String status = cmbStatus.getSelectedItem() != null ? cmbStatus.getSelectedItem().toString().trim() : "";
    java.util.Date utilDate = dateBirth.getDate();

    // ✅ Validate input
    if (firstName.isEmpty() || lastName.isEmpty() || purok.isEmpty() || contact.isEmpty() || status.isEmpty() || utilDate == null) {
        JOptionPane.showMessageDialog(this, "Please fill in all fields before adding.", "Input Error", JOptionPane.WARNING_MESSAGE);
        return;
    }

    java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

    try {
        Connection conn = DBConnection.getConnection();

        // ✅ Check for existing resident by First Name and Last Name (case-insensitive)
        String checkSql = "SELECT * FROM residents WHERE LOWER(TRIM(first_name)) = ? AND LOWER(TRIM(last_name)) = ?";
        PreparedStatement checkStmt = conn.prepareStatement(checkSql);
        checkStmt.setString(1, firstName.toLowerCase());
        checkStmt.setString(2, lastName.toLowerCase());
        ResultSet rs = checkStmt.executeQuery();

        if (rs.next()) {
            JOptionPane.showMessageDialog(this, "Resident already exists!", "Duplicate Found", JOptionPane.WARNING_MESSAGE);
            conn.close();
            return;
        }

        // ✅ Confirm only if no duplicate
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to add this resident?", "Confirm Add", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            conn.close();
            return;
        }

        // ✅ Insert new resident
        String insertSql = "INSERT INTO residents (first_name, last_name, address, contact_number, civil_status, birthdate) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(insertSql);
        stmt.setString(1, firstName);
        stmt.setString(2, lastName);
        stmt.setString(3, purok);
        stmt.setString(4, contact);
        stmt.setString(5, status);
        stmt.setDate(6, sqlDate);

        stmt.executeUpdate();
        conn.close();

        JOptionPane.showMessageDialog(this, "Resident added successfully!");
        ActivityLogger.log("Added resident: " + firstName + " " + lastName, MainDashboard.currentUser);
        loadResidents();
        clearFields();

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
 int selectedRow = tableResidents.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a resident to update.");
        return;
    }

    int id = (int) tableResidents.getValueAt(selectedRow, 0); // Column 0 = ID
    String firstName = txtFirstName.getText().trim();
    String lastName = txtLastName.getText().trim();
    String purok = txtAddress.getText().trim();
    String contact = txtContact.getText().trim();
    String civilStatus = cmbStatus.getSelectedItem().toString();
    java.util.Date birthDate = dateBirth.getDate();

    if (firstName.isEmpty() || lastName.isEmpty() || purok.isEmpty() || contact.isEmpty() || civilStatus.isEmpty() || birthDate == null) {
        JOptionPane.showMessageDialog(this, "Please fill in all fields.");
        return;
    }

    java.sql.Date sqlBirthDate = new java.sql.Date(birthDate.getTime());

    try {
        Connection conn = DBConnection.getConnection();

        // ✅ Check if another resident already has the same first & last name
        String checkSql = "SELECT * FROM residents WHERE LOWER(TRIM(first_name)) = ? AND LOWER(TRIM(last_name)) = ? AND id != ?";
        PreparedStatement checkStmt = conn.prepareStatement(checkSql);
        checkStmt.setString(1, firstName.toLowerCase());
        checkStmt.setString(2, lastName.toLowerCase());
        checkStmt.setInt(3, id); // exclude current resident from check
        ResultSet rs = checkStmt.executeQuery();

        if (rs.next()) {
            JOptionPane.showMessageDialog(this, "Another resident with the same name already exists!", "Duplicate Found", JOptionPane.WARNING_MESSAGE);
            conn.close();
            return;
        }

        // ✅ Confirm update
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to update this resident?", "Confirm Update", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            conn.close();
            return;
        }

        String updateSql = "UPDATE residents SET first_name = ?, last_name = ?, address = ?, contact_number = ?, civil_status = ?, birthdate = ? WHERE id = ?";
        PreparedStatement pst = conn.prepareStatement(updateSql);
        pst.setString(1, firstName);
        pst.setString(2, lastName);
        pst.setString(3, purok);
        pst.setString(4, contact);
        pst.setString(5, civilStatus);
        pst.setDate(6, sqlBirthDate);
        pst.setInt(7, id);

        pst.executeUpdate();
        conn.close();

        JOptionPane.showMessageDialog(this, "Resident updated successfully!");
        ActivityLogger.log("Updated resident: " + firstName + " " + lastName, MainDashboard.currentUser);
        loadResidents();
        clearFields();

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error updating resident: " + e.getMessage());
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void cmbStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbStatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbStatusActionPerformed

    private void txtContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContactActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContactActionPerformed

    private void txtLastNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLastNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtLastNameActionPerformed

    private void txtFirstNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFirstNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFirstNameActionPerformed

    private void txtSearchResidentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchResidentsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSearchResidentsActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to clear the fields?", "Confirm Clear", JOptionPane.YES_NO_OPTION);
    
    if (confirm == JOptionPane.YES_OPTION) {
        clearFields(); // only clears if user confirms
    }
        clearFields();        // TODO add your handling code here:
    }//GEN-LAST:event_btnClearActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> cmbStatus;
    private com.toedter.calendar.JDateChooser dateBirth;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panelForm;
    private javax.swing.JPanel panelTable;
    private javax.swing.JTable tableResidents;
    private javax.swing.JTextField txtAddress;
    private javax.swing.JTextField txtContact;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtLastName;
    private javax.swing.JTextField txtSearchResidents;
    // End of variables declaration//GEN-END:variables
}
