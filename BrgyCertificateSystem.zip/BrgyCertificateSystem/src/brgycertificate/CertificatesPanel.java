/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package brgycertificate;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.ColumnText;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Date;
import java.io.FileOutputStream;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.RowFilter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Image;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Element;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.Phrase;
import java.awt.Component;
import javax.swing.table.JTableHeader;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.JTable;
import java.text.SimpleDateFormat;
import java.awt.Color;
import java.util.Collections;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.ColumnText;









/**
 * CertificatesPanel - JPanel for managing barangay certificates
 */
public class CertificatesPanel extends javax.swing.JPanel {
    
    private TableRowSorter<DefaultTableModel> sorter;
    private java.util.List<String> residentList = new java.util.ArrayList<>();




public CertificatesPanel() {
    
    
    initComponents();
    
    cmbResident.removeAllItems();
    populateResidents();
    txtSearchComboBox.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
    public void insertUpdate(javax.swing.event.DocumentEvent e) {
        filterComboBox();
    }

    public void removeUpdate(javax.swing.event.DocumentEvent e) {
        filterComboBox();
    }

    public void changedUpdate(javax.swing.event.DocumentEvent e) {
        filterComboBox();
    }

    private void filterComboBox() {
        String keyword = txtSearchComboBox.getText().toLowerCase();
        searchResident(keyword); // you already have this method!
    }
});

    loadCertificates();
    styleTable();


    // 🔍 Setup live search on certificate table
    txtSearchResident.setToolTipText("Search resident...");
    txtSearchResident.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyReleased(java.awt.event.KeyEvent evt) {
            searchCertificates(txtSearchResident.getText());
        }
    });
    
    
}
private void styleTable() {
        // Minimal + Bagong Pilipinas theme styling
        Color headerBg = new Color(0, 70, 140); // Dark blue
        Color headerFg = Color.WHITE;
        Color rowEven = new Color(245, 245, 245);
        Color rowOdd = Color.WHITE;
        java.awt.Font headerFont = new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14);
        java.awt.Font rowFont = new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13);

        JTableHeader header = tableCertificates.getTableHeader();
        header.setBackground(headerBg);
        header.setForeground(headerFg);
        header.setFont(headerFont);
        header.setOpaque(true);
        header.setReorderingAllowed(false);

        tableCertificates.setFont(rowFont);
        tableCertificates.setRowHeight(28);

        // Set alternating row colors
        tableCertificates.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? rowEven : rowOdd);
                }
                return c;
            }
        });
    }
public void loadResidentsToComboBox() {
    cmbResident.removeAllItems();
    try {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/brgy_system", "root", "");
        String sql = "SELECT id, CONCAT(first_name, ' ', last_name) AS fullname FROM residents";
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            int id = rs.getInt("id");
            String name = rs.getString("fullname");
            cmbResident.addItem(id + " - " + name);

        }
        con.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error loading residents: " + e.getMessage());
    }
}
public void loadCertificates() {
    DefaultTableModel model = (DefaultTableModel) tableCertificates.getModel();
    model.setRowCount(0); // clear previous data

    try {
        Connection conn = DBConnection.getConnection();
        String sql = "SELECT c.id, CONCAT(r.first_name, ' ', r.last_name) AS full_name, c.certificate_type, c.purpose, c.issued_by, c.date_issued " +
                     "FROM certificates c INNER JOIN residents r ON c.resident_id = r.id";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            Object[] row = {
                rs.getInt("id"),
                rs.getString("full_name"),
                rs.getString("certificate_type"),
                rs.getString("purpose"),
                rs.getString("issued_by"),
                rs.getDate("date_issued")
            };
            model.addRow(row);
        }
tableCertificates.getColumnModel().getColumn(0).setMinWidth(0);
tableCertificates.getColumnModel().getColumn(0).setMaxWidth(0);
tableCertificates.getColumnModel().getColumn(0).setWidth(0);

        conn.close();
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Failed to load certificates: " + e.getMessage());
    }
}



private void searchCertificates(String query) {
    DefaultTableModel model = (DefaultTableModel) tableCertificates.getModel();
    
    if (sorter == null) {
        sorter = new TableRowSorter<>(model);
        tableCertificates.setRowSorter(sorter);
    }

    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + query));
}
private void searchResident(String query) {
    cmbResident.removeAllItems();
    for (String resident : residentList) {
        if (resident.toLowerCase().contains(query.toLowerCase())) {
            cmbResident.addItem(resident);
        }
    }
}


private void populateResidents() {
    residentList.clear();
    cmbResident.removeAllItems();

    try {
        Connection conn = DBConnection.getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT id, first_name, last_name FROM residents");

        while (rs.next()) {
            int id = rs.getInt("id");
            String fullName = rs.getString("first_name") + " " + rs.getString("last_name");
            String display = id + " - " + fullName;
            residentList.add(display);
        }

        conn.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Failed to load residents: " + e.getMessage());
    }

    java.util.Collections.sort(residentList);

    for (String resident : residentList) {
        cmbResident.addItem(resident); // 👈 this will now include ID
    }
}



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        leftPanel = new javax.swing.JPanel();
        btnIssueandPrint = new javax.swing.JButton();
        txtIssuedBy = new javax.swing.JTextField();
        txtPurpose = new javax.swing.JTextField();
        cmbType = new javax.swing.JComboBox<>();
        cmbResident = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtSearchComboBox = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        tablePanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableCertificates = new javax.swing.JTable();
        txtSearchResident = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.Y_AXIS));

        jPanel1.setMaximumSize(new java.awt.Dimension(32767, 500));
        jPanel1.setMinimumSize(new java.awt.Dimension(0, 40));

        jLabel4.setFont(new java.awt.Font("Wide Latin", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("GENERATE CERTIFICATE");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(407, 407, 407)
                .addComponent(jLabel4)
                .addContainerGap(505, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addContainerGap())
        );

        add(jPanel1);

        leftPanel.setBackground(new java.awt.Color(0, 82, 147));
        leftPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        leftPanel.setForeground(new java.awt.Color(255, 255, 255));
        leftPanel.setAlignmentY(10.0F);
        leftPanel.setMaximumSize(new java.awt.Dimension(1000, 200));
        leftPanel.setPreferredSize(new java.awt.Dimension(200, 400));

        btnIssueandPrint.setBackground(new java.awt.Color(102, 255, 102));
        btnIssueandPrint.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        btnIssueandPrint.setText("ISSUE CERTIFICATE");
        btnIssueandPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIssueandPrintActionPerformed(evt);
            }
        });

        txtPurpose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPurposeActionPerformed(evt);
            }
        });

        cmbType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Barangay Clearance", "Certificate of Indigency", "Certificate of Residency", "Certificate of Low Income" }));
        cmbType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbTypeActionPerformed(evt);
            }
        });

        cmbResident.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbResidentActionPerformed(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(204, 204, 204));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel2.setText("Issued By:");

        jLabel3.setBackground(new java.awt.Color(204, 204, 204));
        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel3.setText("Purpose:");

        jLabel6.setBackground(new java.awt.Color(204, 204, 204));
        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel6.setText("Please Choose Resident:");

        txtSearchComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSearchComboBoxActionPerformed(evt);
            }
        });

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Search:");

        javax.swing.GroupLayout leftPanelLayout = new javax.swing.GroupLayout(leftPanel);
        leftPanel.setLayout(leftPanelLayout);
        leftPanelLayout.setHorizontalGroup(
            leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftPanelLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(leftPanelLayout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 211, Short.MAX_VALUE)
                        .addGap(187, 187, 187)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtSearchComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(leftPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(cmbResident, javax.swing.GroupLayout.PREFERRED_SIZE, 609, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(148, 148, 148)
                .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(txtIssuedBy, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(txtPurpose, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnIssueandPrint, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(cmbType, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        leftPanelLayout.setVerticalGroup(
            leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, leftPanelLayout.createSequentialGroup()
                .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(leftPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(cmbType, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)
                        .addComponent(jLabel3))
                    .addGroup(leftPanelLayout.createSequentialGroup()
                        .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(leftPanelLayout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, leftPanelLayout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtSearchComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7))
                                .addGap(8, 8, 8)))
                        .addComponent(cmbResident, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtPurpose, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtIssuedBy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 85, Short.MAX_VALUE)
                .addComponent(btnIssueandPrint, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(72, 72, 72))
        );

        add(leftPanel);

        tableCertificates.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Full Name", "Certificate Type", "Purpose", "Issued By", "Date Issued"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tableCertificates);
        if (tableCertificates.getColumnModel().getColumnCount() > 0) {
            tableCertificates.getColumnModel().getColumn(0).setResizable(false);
            tableCertificates.getColumnModel().getColumn(1).setResizable(false);
            tableCertificates.getColumnModel().getColumn(2).setResizable(false);
            tableCertificates.getColumnModel().getColumn(3).setResizable(false);
            tableCertificates.getColumnModel().getColumn(4).setResizable(false);
            tableCertificates.getColumnModel().getColumn(5).setResizable(false);
        }

        jLabel1.setText("Search:");

        jLabel5.setFont(new java.awt.Font("Wide Latin", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("CERTIFICATE ISSUED LOGS");

        javax.swing.GroupLayout tablePanelLayout = new javax.swing.GroupLayout(tablePanel);
        tablePanel.setLayout(tablePanelLayout);
        tablePanelLayout.setHorizontalGroup(
            tablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tablePanelLayout.createSequentialGroup()
                .addGroup(tablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tablePanelLayout.createSequentialGroup()
                        .addGap(229, 229, 229)
                        .addComponent(jLabel5)
                        .addGap(57, 57, 57)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtSearchResident, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(tablePanelLayout.createSequentialGroup()
                        .addGap(165, 165, 165)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1003, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(363, Short.MAX_VALUE))
        );
        tablePanelLayout.setVerticalGroup(
            tablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tablePanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(tablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtSearchResident, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(91, Short.MAX_VALUE))
        );

        add(tablePanel);
    }// </editor-fold>//GEN-END:initComponents

    private void cmbResidentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbResidentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbResidentActionPerformed

    private void cmbTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbTypeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbTypeActionPerformed

    private void txtPurposeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPurposeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPurposeActionPerformed

    private void btnIssueandPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIssueandPrintActionPerformed
 try {
        // 🔍 Check if resident is selected
        if (cmbResident.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please select a resident.", "Missing Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 📝 Check required fields
        if (txtPurpose.getText().trim().isEmpty() || txtIssuedBy.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in both 'Purpose' and 'Issued By' fields.", "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 📌 Get values
        String selectedItem = cmbResident.getSelectedItem().toString();
        int residentId = Integer.parseInt(selectedItem.split(" - ")[0]);
        String fullName = selectedItem.split(" - ")[1];

        String certificateType = cmbType.getSelectedItem().toString();
        String purpose = txtPurpose.getText().trim();
        String issuedBy = txtIssuedBy.getText().trim();
        String dateIssued = new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());

        // 🖨️ Generate PDF FIRST — and exit early if user cancels
        boolean pdfSaved = generatePDF(certificateType, fullName); // ← now returns boolean
        if (!pdfSaved) {
            JOptionPane.showMessageDialog(this, "PDF generation was cancelled. Certificate was NOT issued.");
            return;
        }

        // 💾 Then insert into database
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/brgy_system", "root", "");
        String sql = "INSERT INTO certificates (resident_id, certificate_type, purpose, issued_by, date_issued) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setInt(1, residentId);
        pst.setString(2, certificateType);
        pst.setString(3, purpose);
        pst.setString(4, issuedBy);
        pst.setString(5, dateIssued);
        pst.executeUpdate();

        // ✅ Show success
        JOptionPane.showMessageDialog(this, "Certificate issued successfully!");
        ActivityLogger.log("Issued certificate for: " + fullName, MainDashboard.currentUser);


        // 🔃 Reset
        cmbResident.setSelectedIndex(0);
        cmbType.setSelectedIndex(0);
        txtPurpose.setText("");
        txtIssuedBy.setText("");
        loadCertificates();

    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    }

        // TODO addkoindling code here:
    }//GEN-LAST:event_btnIssueandPrintActionPerformed

    private void txtSearchComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSearchComboBoxActionPerformed
public boolean generatePDF(String certType, String residentName) {
    Document document = new Document();
    try {
        String fileName = residentName.replace(" ", "_") + "_" + certType.replace(" ", "_") + ".pdf";
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setSelectedFile(new java.io.File(fileName));
        int option = fileChooser.showSaveDialog(this);
        if (option != JFileChooser.APPROVE_OPTION) return false;

        String savePath = fileChooser.getSelectedFile().getAbsolutePath();
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(savePath));
        document.open();

        // Logos
        Image logoLeft = Image.getInstance("src/brgycertificate/logo_left.png");
        Image logoRight = Image.getInstance("src/brgycertificate/logo_right.png");
        logoLeft.scaleToFit(60, 60);
        logoRight.scaleToFit(60, 60);
        logoLeft.setAbsolutePosition(60, 750);
        logoRight.setAbsolutePosition(470, 750);
        document.add(logoLeft);
        document.add(logoRight);

        // Fonts
        Font headerFont = FontFactory.getFont("Times-Bold", 14);
        Font subHeaderFont = FontFactory.getFont("Times-Roman", 12);
        Font bodyFont = FontFactory.getFont("Times-Roman", 12);
        Font titleFont = FontFactory.getFont("Times-Bold", 16);

        // Header
        Paragraph header = new Paragraph();
        header.setAlignment(Element.ALIGN_CENTER);
        header.add(new Phrase("Republic of the Philippines\n", subHeaderFont));
        header.add(new Phrase("Province of Aurora\n", subHeaderFont));
        header.add(new Phrase("Municipality of Maria Aurora\n", subHeaderFont));
        header.add(new Phrase("BARANGAY DIKILDIT\n\n", headerFont));
        header.add(new Phrase(certType.toUpperCase() + "\n\n", titleFont));
        document.add(header);

        // Body content
        String body = switch (certType) {
            case "Barangay Clearance" ->
                "This is to certify that Mr./Ms. " + residentName + " is a bona fide resident of Barangay Dikildit and has no derogatory record as of this date. This further certifies that he/she "
                + "is never been suspected of being a member of any subversive organization and has no any derogatory record in this barangay.";
            case "Certificate of Indigency" ->
                "This is to certify that Mr./Ms. " + residentName + " is considered indigent and this certificate is issued to avail of any legal purpose.";
            case "Certificate of Residency" ->
                "This is to certify that Mr./Ms. " + residentName + " has been a resident of Barangay Dikildit for more than five (5) years. This certification is issued "
                + "upon the request of the above-named person for any legal purposes";
            case "Certificate of Low Income" ->
                "This is to certify that Mr./Ms. " + residentName + " is classified as a low-income individual based on barangay records. Further certifies as per the assessment conducted by this office of their economic "
                + "and social condition, it has been found that they belong to the LOW INCOME of Indigent Families";
            default -> "";
        };

        document.add(new Paragraph(body + "\n\n", bodyFont));

        // Date
        String formattedDate = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("MMMM dd, yyyy"));
        document.add(new Paragraph("Issued this " + formattedDate + " at Barangay Dikildit, Maria Aurora, Aurora.\n\n", bodyFont));

        // Right thumbmark box
        PdfContentByte cb = writer.getDirectContent();
        cb.rectangle(400, 200, 100, 50);
        cb.stroke();
        ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase("Right Thumbmark"), 450, 190, 0);

        // Signature
        Paragraph signatory = new Paragraph("\n\n\nApproved by:\n\nCAMILO MANONOD\nPunong Barangay", bodyFont);
        signatory.setAlignment(Element.ALIGN_LEFT);
        document.add(signatory);

        JOptionPane.showMessageDialog(this, "PDF saved to:\n" + savePath);
        return true;

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Failed to generate PDF:\n" + e.getMessage());
        return false;
    } finally {
        document.close();
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnIssueandPrint;
    private javax.swing.JComboBox<String> cmbResident;
    private javax.swing.JComboBox<String> cmbType;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JTable tableCertificates;
    private javax.swing.JPanel tablePanel;
    private javax.swing.JTextField txtIssuedBy;
    private javax.swing.JTextField txtPurpose;
    private javax.swing.JTextField txtSearchComboBox;
    private javax.swing.JTextField txtSearchResident;
    // End of variables declaration//GEN-END:variables
}