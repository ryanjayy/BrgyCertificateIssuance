/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package brgycertificate;

/**
 *
 * @author Erika
 */
import java.sql.Connection;
import java.sql.PreparedStatement;

public class ActivityLogger {
    public static void log(String action, String user) {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "INSERT INTO activity_logs (action, user) VALUES (?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, action);
            pst.setString(2, user);
            pst.executeUpdate();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}